const CustomRenderBlock = ({ content }) => {
  return <div>{content}</div>;
};

export default CustomRenderBlock;
